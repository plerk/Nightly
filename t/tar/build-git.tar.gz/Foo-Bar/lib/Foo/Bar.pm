package Foo::Bar;

use strict;
use warnings;

# ABSTRACT: Something Wicked
our $VERSION = '0.01'; # VERSION

1;

__END__
=pod

=head1 NAME

Foo::Bar - Something Wicked

=head1 VERSION

version 0.01

=head1 AUTHOR

Graham Ollis <gollis@sesda2.com>

=head1 COPYRIGHT AND LICENSE

This software is copyright (c) 2013 by NASA GSFC.  No
license is granted to other entities.

=cut

