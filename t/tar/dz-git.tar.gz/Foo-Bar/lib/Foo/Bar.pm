package Foo::Bar;

use strict;
use warnings;

# ABSTRACT: Something Wicked
# VERSION

1;
